var API_KEY = 'u86xPDUfORcuSqUoaJJvxrIB9xJp0Atg'
var API_URL = 'https://www.kimonolabs.com/api/d3rpj7om'
var PARAMS = '?apikey=' + API_KEY;
exports.REQUEST_URL = API_URL + PARAMS;
exports.HN_ITEM_ENDPOINT = 'https://hacker-news.firebaseio.com/v0/item/';