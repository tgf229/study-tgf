# HackerNews-React-Native  

[Hacker News](https://news.ycombinator.com/) reader for iOS, made with [React-Native](https://github.com/facebook/react-native).

This project uses [ParseHTML](https://github.com/iSimar/ParseHTML-React-Native) to render HTML code in the iOS Application.

## Screenshots:  
<center>
<img src="http://i.imgur.com/evZsZub.png" height="500"  width="200"/>
<img src="http://i.imgur.com/B7fp7lh.png" height="470"  width="240"/>
<img src="http://i.imgur.com/74ly7GE.png" height="500"  width="200"/>
</center>